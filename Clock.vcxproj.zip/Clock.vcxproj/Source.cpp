//Taylor Cruz 03/21/2021 CS210
#include <iostream>
#include <iomanip>
using namespace std;

int clockTwelve() { //for the clock showing twelve

	int hour = 03;
	int minute = 22;
	int second = 01;
	cout << "**************************" << endl;
	cout << "*     12 Hour Clock      *" << endl;
	while (hour <= 12) { //will display hour only up to 12
		cout << "*     " << hour << ":";
	}
	while (minute < 60) { //will display minute only up to 59
		cout << minute << ":";
	}
	while (second < 60) { //will display seconds only up to 59
		cout << second << " P M     *" << endl;
	}
	cout << "**************************";
	return 0;
}
int clockTwentyFour() { //for the clock showing hours up to 24
	int hour = 15;
	int minute = 22;
	int second = 01;
	cout << "**************************" << endl;
	cout << "*      24 Hour Clock      *" << endl;

	while (hour <= 24) { //will display hour only up to 24
		cout << "*     " << hour << ":";
	}
	while (minute < 60) { //will display minutes only up to 59
		cout << minute << ":";
	}
	while (second < 60) { //will display seconds up to 59
		cout << second << "     *" << endl;
	}
	cout << "**************************";
	return 0;
}
void userInput(int addHour, int addMinute, int addSecond, int exit, int input) { //allows the user to modify clocks
	addHour = 1;
	addMinute = 2;
	addSecond = 3;
	exit = 4;
	int hour;
	int minute;
	int second;
	
	cout << "**************************" << endl;
	cout << "* 1-Add One Hour         *" << endl;
	cout << "* 2-Add One Minute       *" << endl;
	cout << "* 3-Add One Second       *" << endl;
	cout << "* 4-Exit Program         *" << endl;
	
	//prompt user to input option
	cout << "Please select from above options" << endl;

	//gather user input
	cin >> input;

	if (input == 1) { //add 1 to hour in both functions
		hour = hour + 1;
		
	}
	else if (input == 2) {//add 1 to minute in both functions
		minute = minute + 1;
	}
	else if (input == 3) {//add 1 to second in both functions
		second = second + 1;
	}
	else if (input == 4) { //program will be exited
		cout << endl;
	}
	return;
}

int main() { //will output the functions

	cout << clockTwelve() << "    " << clockTwentyFour() << endl;
	cout << userInput();
	return 0;
	
}